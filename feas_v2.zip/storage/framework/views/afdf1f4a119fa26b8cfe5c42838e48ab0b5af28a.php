<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FEAS - Relatório de cabos</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <style>
        body {
            font-family: Verdana, Arial, Helvetica, sans-serif !important;
            font-size: 12px;
        }

        th, td {
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>

<body>

    <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
            <td width="20%" style="text-align: left !important">
                <img src="<?php echo e(public_path('img/system/feas-logo.png')); ?>" style="width: 100px">
            </td>
            <td width="50%" style="font-size: 16px !important; text-align: center !important;">
                <h3>Relatório de cabos</h3>
            </td>
            <td width="30%" style="text-align: right !important">
                <b>Rline Telecom LTDA</b><br>
                Rua Cinco - Área Industrial<br>
                CNPJ: 13.500.755/0001-05<br>
                46 3555-8000 / Matriz<br>
                suporte@rline.com.br<br>
            </td>
        </tr>
    </table>

    <div id="middle" style="text-align: center !important">
    <hr>
        <span style="font-size: 12px">
            <a value="<?php echo e(date_default_timezone_set('America/Sao_Paulo')); ?>"></a>
            Este relatório foi gerado dia <?php echo e(date('d/m/Y')); ?> às <?php echo e(date('H:i:s')); ?> por <?php echo e(Auth::user()->name); ?>

        </span>
    <hr>
    </div>

    <div class="container" style="text-align: left !important;">
        <?php if($response->count() !== 0): ?>
        <table width="100%">
            <thead>
                <tr style="background-color: #F1F1F1 !important">
                    <th><b>#</b></th>
                    <th><b>Nome</b></th>
                    <th><b>Cor Hex.</b></th>
                    <th><b>Pontilhado?</b></th>
                    <th><b>Tamanho</b></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border-bottom: 1px solid #ddd !important;"><?php echo e($cable->id); ?></td>
                    <td style="border-bottom: 1px solid #ddd !important;"><?php echo e($cable->name); ?></td>
                    <td style="border-bottom: 1px solid #ddd !important; color: <?php echo e($cable->color); ?>"><?php echo e($cable->color); ?></td>
                    <td style="border-bottom: 1px solid #ddd !important;">
                        <?php if($cable->dotted === 1): ?>
                        Sim
                        <?php else: ?>
                        Não
                        <?php endif; ?>
                    </td>
                    <td style="border-bottom: 1px solid #ddd !important;"><?php echo e($cable->size); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <span style="margin-top: 50% !important">Desculpe, essa consulta não encontrou resultados.</span>
        <?php endif; ?>
    </div>

</body><?php /**PATH D:\Data\Documents\feas_v2\resources\views/relatorios_pdfs/cables.blade.php ENDPATH**/ ?>