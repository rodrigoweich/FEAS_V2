

<?php $__env->startSection('extra-header'); ?>
<script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow">
                <div class="card-body">

                    <?php echo e(__('Edit existing')); ?>

                    <div id="divider" class="mb-5"></div>

                    <form action="<?php echo e(route('admin.roles.update', $role)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputname"><?php echo e(__('Name')); ?></label>
                                <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($role->name); ?>" autofocus>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="rules[]"><?php echo e(__('Rules')); ?>:</label>
                                <select name="rules[]" class="mselectRules form-control" multiple="true">
                                    <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rule->id); ?>" <?php if($role->rules->pluck('id')->contains($rule->id)): ?> selected <?php endif; ?>><?php echo e(__($rule->display_name)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <span class="float-right">
                            <a class="btn btn-danger" href="<?php echo e(route('admin.roles.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Cancel and return')); ?>"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Edit')); ?></button>
                        </span>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<script type='text/javascript'>
    $(".mselectRules").select2();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>