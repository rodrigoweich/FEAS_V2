<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm" style="height: 30px">
    <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2" aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent2">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <i class="fas fa-map"></i> <span id="mapTypesDpMenu"><?php echo e(__('Padrão + Satélite')); ?></span> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'roadmap', 'Padrão')">
                            <?php echo e(__('Padrão')); ?>

                        </a>
                        <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'satellite', 'Satélite')">
                            <?php echo e(__('Satélite')); ?>

                        </a>
                        <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'terrain', 'Padrão + Terreno')">
                            <?php echo e(__('Padrão + Terreno')); ?>

                        </a>
                        <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'hybrid', 'Padrão + Satélite')">
                            <?php echo e(__('Padrão + Satélite')); ?>

                        </a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/components/cities_navbar.blade.php ENDPATH**/ ?>