<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand text-detail text-uppercase" href="<?php echo e(route('home')); ?>">
            <?php echo e(config('app.name', 'Laravel')); ?>

        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">

            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php if(Storage::disk('public')->exists(Auth::user()->avatar)): ?>
                            <span class="float-left mr-2"><img id="prevImg" src="<?php echo e(config('global.type_asset')('/storage/'.Auth::user()->avatar)); ?>" alt="Avatar" class="avatar-image"></span>
                            <?php else: ?>
                            <span class="float-left mr-2"><img id="prevImg" src="<?php echo e(config('global.type_asset')('img/users/avatar.png')); ?>" alt="Avatar" class="avatar-image"></span>
                            <?php endif; ?>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('admin.users.index')); ?>">
                                <?php echo e(__('Users')); ?><span class="float-right"><i class="fas fa-users"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.roles.index')); ?>">
                                <?php echo e(__('Roles')); ?><span class="float-right"><i class="fas fa-tags"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.cities.index')); ?>">
                                <?php echo e(__('Cities')); ?><span class="float-right"><i class="fas fa-city"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.states.index')); ?>">
                                <?php echo e(__('States')); ?><span class="float-right"><i class="fas fa-flag"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.notices.index')); ?>">
                                <?php echo e(__('Notices')); ?><span class="float-right"><i class="fas fa-bullhorn"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.roles.index')); ?>">
                                <?php echo e(__('Reports')); ?><span class="float-right"><i class="fas fa-chart-pie"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('default.process_stage_one.index')); ?>">
                                <?php echo e(__('Process')); ?> - 1<span class="float-right"><i class="fas fa-microchip"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.roles.index')); ?>">
                                <?php echo e(__('Process')); ?> - 2<span class="float-right"><i class="fas fa-microchip"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.roles.index')); ?>">
                                <?php echo e(__('Process')); ?> - 3<span class="float-right"><i class="fas fa-microchip"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.roles.index')); ?>">
                                <?php echo e(__('Process')); ?> - 4<span class="float-right"><i class="fas fa-microchip"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('default.cables.index')); ?>">
                                <?php echo e(__('Cables')); ?><span class="float-right"><i class="fas fa-minus"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('default.boxes.index')); ?>">
                                <?php echo e(__('Boxes')); ?><span class="float-right"><i class="fas fa-bookmark"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('admin.roles.index')); ?>">
                                <?php echo e(__('Process List')); ?><span class="float-right"><i class="fas fa-list"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('default.customers.index')); ?>">
                                <?php echo e(__('Customers')); ?><span class="float-right"><i class="fas fa-user-friends"></i></span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('users.profile', Auth::user()->id)); ?>">
                                <?php echo e(__('My profile')); ?><span class="float-right"><i class="fas fa-user-circle"></i></span>
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?><span class="float-right"><i class="fas fa-sign-out-alt"></i></span>
                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/components/navbar.blade.php ENDPATH**/ ?>