

<?php $__env->startSection('extra-header'); ?>
<script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-notify-3.1.3/bootstrap-notify.js')); ?>"></script>
<link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/select2-bootstrap4.css')); ?>" rel="stylesheet">
<script type="text/javascript" src="<?php echo e(asset('vendor/js/gmaps.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendor/js/jquery.mask.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('fcontent'); ?>
<?php if(!config('global.google_maps_key')): ?>
<div class="container my-5 alert alert-danger">
    <h6 class="m-0 text-justify"><i class="fas fa-exclamation-triangle"></i> Foram encontradas inconsistências na sua chave de acesso do Google Maps API. Por favor, verifique a sua chave e tente novamente.</h6>
</div>
<?php else: ?>
<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
        <div class="list-group list-group-flush">
            <div id="divider">
                <a id="navbarDropdown" class="nav-link dropdown-toggle list-group-item list-group-item-action bg-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <span class="float-right"><i class="fas fa-map"></i></span> <span id="mapTypesDpMenu">Padrão + Satélite</span> <span class="caret"></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'roadmap', 'Default')">
                        Padrão
                    </a>
                    <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'satellite', 'Satellite')">
                        Satélite
                    </a>
                    <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'terrain', 'Default + Terrain')">
                        Padrão + Terreno
                    </a>
                    <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'hybrid', 'Default + Satellite')">
                        Padrão + Satélite
                    </a>
                </div>
            </div>
            <div id="divider">
                <a id="navbarDropdown" class="nav-link dropdown-toggle list-group-item list-group-item-action bg-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <span class="float-right"><i id="figureType" class="fas fa-home"></i></span> <span id="mapTypesDpMenu">Opções de ícones</span> <span class="caret"></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-home')">
                        Casa<span class="float-right"><i class="fas fa-home"></i></span>
                    </a>
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-hotel')">
                        Hotel<span class="float-right"><i class="fas fa-hotel"></i></span>
                    </a>
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-building')">
                        Construção<span class="float-right"><i class="fas fa-building"></i></span>
                    </a>
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-hospital')">
                        Hospital<span class="float-right"><i class="fas fa-hospital"></i></span>
                    </a>
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-store')">
                        Loja<span class="float-right"><i class="fas fa-store"></i></span>
                    </a>
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-warehouse')">
                        Armazém<span class="float-right"><i class="fas fa-warehouse"></i></span>
                    </a>
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-church')">
                        Igreja<span class="float-right"><i class="fas fa-church"></i></span>
                    </a>
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-graduation-cap')">
                        Centro educacional<span class="float-right"><i class="fas fa-graduation-cap"></i></span>
                    </a>
                    <a class="dropdown-item" onclick="changeFigureType('fas fa-industry')">
                        Industria<span class="float-right"><i class="fas fa-industry"></i></span>
                    </a>
                </div>
            </div>
            <a onclick="createChangeCustomerPointFunction()" class="list-group-item list-group-item-action bg-light">Editar localização<span class="float-right"><i class="far fa-edit"></i></span></a>
            <a onclick="showAlertSave()" class="list-group-item list-group-item-action bg-light">Salvar mudanças<span class="float-right"><i class="fas fa-map-marked"></i></span></a>
            <a href="<?php echo e(route('default.process_stage_one.index')); ?>" class="list-group-item list-group-item-action bg-light text-danger">Cancelar e voltar<span class="float-right"><i class="far fa-hand-point-left"></i></span></a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <div class="container-fluid" id="gmap">
        </div>
    </div>
    <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->
<?php endif; ?>

<div class="modal fade" tabindex="-1" role="dialog" id="alertSave">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Informação do processo</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="thisForm" action="<?php echo e(route('default.process_stage_one.update', $response)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <input type="hidden" id="route" name="route">
                    <input type="hidden" id="cable_id" name="cable_id">
                    <div class="row mb-3">
                        <div class="col">
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label for="inputname">Nome</label>
                                    <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($response->customer()->get()->first()->name); ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="surname">Sobrenome</label>
                                    <input type="text" class="form-control" id="surname" name="surname" value="<?php echo e($response->customer()->get()->first()->surname); ?>">
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="phone">Telefone</label>
                                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($response->customer()->get()->first()->phone); ?>">
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="contract_number">Número do contrato</label>
                                    <input type="number" class="form-control" id="contract_number" name="contract_number" min="0" max="2147483647" value="<?php echo e($response->customer()->get()->first()->contract_number); ?>">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-2">
                                    <label for="number">Número do endereço</label>
                                    <input type="number" class="form-control" id="number" name="number" value="<?php echo e($response->address()->get()->first()->number); ?>" min="0" max="2147483647">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="end_description">Descrição do endereço</label>
                                    <input type="text" class="form-control" id="end_description" name="end_description" value="<?php echo e($response->address()->get()->first()->end_description); ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="complement">Complemento do endereço</label>
                                    <input type="text" class="form-control" id="complement" name="complement" value="<?php echo e($response->address()->get()->first()->complement); ?>">
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="city">Cidade</label>
                                    <select name="city" id="city" class="form-control selectTwo" style="width: 100%">
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city->id); ?>" <?php if($response->address()->get()->first()->cities_id == $city->id): ?> selected <?php endif; ?>><?php echo e(__($city->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label for="lat">Latitude</label>
                                    <input type="text" class="form-control" id="lat" name="lat" value="<?php echo e($response->customer()->get()->first()->m_lat); ?>" readonly>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="lng">Longitude</label>
                                    <input type="text" class="form-control" id="lng" name="lng" value="<?php echo e($response->customer()->get()->first()->m_lng); ?>" readonly>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="zoom">Zoom</label>
                                    <input type="number" min="0" max="30" class="form-control" id="zoom" name="zoom" value="<?php echo e($response->customer()->get()->first()->m_zoom); ?>" readonly>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="icon">Nome do ícone</label>
                                    <input type="text" class="form-control" id="icon" name="icon" value="<?php echo e($response->customer()->get()->first()->m_icon); ?>" readonly>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <span class="float-right">
                        <a class="btn btn-danger" href="<?php echo e(route('default.process_stage_one.index')); ?>" role="button">Cancelar e voltar</a>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Fechar essa janela</button>
                        <button type="submit" class="btn btn-success">Salvar mudanças</button>
                    </span>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<?php if(config('global.google_maps_key')): ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('global.google_maps_key')); ?>&callback=initMap" async defer></script>
<?php endif; ?>

<script type="text/javascript"> $(".selectTwo").select2({ theme: "bootstrap4" }); </script>

<script type='text/javascript'>
// FUNÇÃO QUE VAI SELECIONAR A FONTE QUE REPRESENTA O CLIENTE
function selectCustomerMarker() {
    createNewCustomerPoint({lat: <?php echo e($response->customer()->get()->first()->m_lat); ?>, lng: <?php echo e($response->customer()->get()->first()->m_lng); ?>}, selectCustomerIconPath("<?php echo e($response->customer()->get()->first()->m_icon); ?>"));
    gmap.setCenter({lat: <?php echo e($response->customer()->get()->first()->m_lat); ?>, lng: <?php echo e($response->customer()->get()->first()->m_lng); ?>});
    gmap.setZoom(<?php echo e($response->customer()->get()->first()->m_zoom); ?>);
};

// FUNÇÃO PRINCIPAL, RODA AS CONFIGURAÇÕES PARA CRIAR O MAPA NA TELA DO USUÁRIO
function initMap() {
    gmap = new google.maps.Map(document.getElementById('gmap'), {
        center: {lat: -25.721822, lng: -53.765546},
        mapTypeId: "hybrid",
        zoom: 15,
        zoomControl: true,
        scaleControl: false,
        streetViewControl: false,
        rotateControl: false,
        fullscreenControl: false,
        mapTypeControl: false,
        mapTypeControlOptions: {
            style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
            mapTypeIds: [
                'roadmap',
                'terrain',
                'satellite',
                'hybrid'
            ]
        }
    });

    selectCustomerMarker();

    const controlDiv = document.createElement("div");
    createMenuButtonOnMap(controlDiv, gmap);
    gmap.controls[google.maps.ControlPosition.TOP_LEFT].push(controlDiv);
};

<?php if($errors->any()): ?>
showAlertSave();
<?php endif; ?>
</script>

<script type="text/javascript">
// VALIDAÇÕES E MÁSCARAS
$("#phone").mask('(00) 00000-0000');

$("#thisForm").submit(function() {
  $("#phone").unmask();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Documents\feas_v2\resources\views/default/process_stage_one/edit.blade.php ENDPATH**/ ?>