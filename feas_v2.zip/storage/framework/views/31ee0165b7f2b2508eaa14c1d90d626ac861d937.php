

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <a class="btn button-without-style btn-sm" href="<?php echo e(route('home')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Return to app')); ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                            <span class="align-middle">&nbsp;&nbsp;Caixas de atendimento</span>
                        </div>
                        <div class="col-8 text-right">
                            <form action="<?php echo e(route('default.boxes.search')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="input-group input-group-sm">
                                    <input type="text" name="dataToSearch" class="form-control panel-border" placeholder="Pesquise por nome, descrição ou cidade">
                                    <div class="input-group-append">
                                        <button class="btn panel-border" type="submit" data-toggle="tooltip" data-placement="top" title="Pesquisar"><i class="fas fa-search"></i></button>
                                        <a class="btn panel-border" href="<?php echo e(route('default.boxes.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Cancelar e voltar"><i class="fas fa-undo-alt"></i></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="row">
                        <div class="col text-right">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-cables')): ?>
                            <a class="btn btn-detail btn-sm" href="<?php echo e(route('default.boxes.create')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Criar uma nova">
                                <i class="fas fa-plus"></i>
                            </a>
                        <?php endif; ?>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered table-hover table-borderless text-center" style="height: 100px;">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nome</th>
                                    <th>Descrição</th>
                                    <th>Quantidade</th>
                                    <th>Ocupadas</th>
                                    <th>Disponíveis</th>
                                    <th>Cidade</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row" class="align-middle"><?php echo e($data->id); ?></td>
                                    <td class="align-middle"><?php echo e($data->sb_name); ?></td>
                                    <td class="align-middle"><?php echo e($data->description); ?></td>
                                    <td class="align-middle"><?php echo e($data->amount); ?></td>
                                    <td class="align-middle"><?php echo e($data->busy); ?></td>
                                    <td class="align-middle"><?php if($data->amount - $data->busy < 0): ?><span class="text-danger"><?php echo e($data->amount - $data->busy); ?></span><?php elseif($data->amount - $data->busy > 0): ?><span class="text-success"><?php echo e($data->amount - $data->busy); ?></span><?php else: ?><?php echo e($data->amount - $data->busy); ?><?php endif; ?></td>
                                    <td class="align-middle"><?php echo e($data->ct_name); ?></td>
                                    <td class="align-middle">
                                        <div class="d-flex align-content-center">
                                            <button type="button" class="button-without-style mr-1 get-customers-data" this-box-id="<?php echo e($data->id); ?>" data-toggle="tooltip" data-placement="top" title="Ver clientes vinculados a essa caixa"><i class="fas text-dark fa-eye fa-lg"></i></button>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-service_boxes')): ?>
                                            <a href="<?php echo e(route('default.boxes.edit', $data->id)); ?>"><button type="button" class="button-without-style mr-1" data-toggle="tooltip" data-placement="top" title="Editar"><i class="fas text-dark fa-edit fa-lg"></i></button></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-service_boxes')): ?>
                                        <form id="dataIds_<?php echo e($data->id); ?>" action="<?php echo e(route('default.boxes.destroy', $data->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="button-without-style ml-1" data-toggle="tooltip" data-placement="top" title="Deletar"><i class="fas text-dark fa-trash fa-lg"></i></button>
                                        </form>
                                        <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12 mt-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-center">
                                <?php echo e($response->onEachSide(1)->links()); ?>

                    </div>
                    <div class="d-flex justify-content-center">
                        <span class="align-middle">Mostrando <?php echo e($response->count()); ?> de <?php echo e($response->total()); ?> resultados</span>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="finishProcess">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Vínculos por caixa</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="tex">
                <table class="table table-ordered table-hover" id="customersTable">
                    <thead>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<script type='text/javascript'>
<?php $__currentLoopData = $hasProcesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    $("#dataIds_" + <?php echo e($key); ?>).click(function(e) {
        if(<?php echo e($h); ?> != 0) {
            if(confirm("Existem clientes vinculados a essa caixa, deseja realmente deletar?")) {} else {
                return false;
            }
        } else {
            if(confirm("Deseja mesmo deletar?")) {} else {
                return false;
            }
        }
    });
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

$('.get-customers-data').on('click', function() {
    var id = $(this).attr('this-box-id');
    $.ajax({
        type: "get",
        url: "<?php echo e(route('default.boxes.customers')); ?>",
        data: { id: id },
        success: function(data) {
            if(data.length > 0) {
                $("#customersTable>thead").append('<tr><th>#</th><th>Nome</th><th>Telefone</th><th>Contrato Nº</th><th>LAT</th><th>LNG</th></tr>');
                for(i=0; i<data.length; i++){
                    linha = montarLinha(data[i]);
                    $('#customersTable>tbody').append(linha);
                }
                $("#finishProcess").modal('show');
            } else {
                $("#customersTable>thead tr").remove();
                $('#tex').append("<span>Sentimos muito, mas essa caixa ainda não tem clientes vinculados.</span>");
                $("#finishProcess").modal('show');
            }
        },
        error: function(data) {
            console.log(data);
        }
    })
});

function montarLinha(p){
    var linha = "<tr>"+
                    "<td>"+ p.id + "</td>"+
                    "<td>"+ p.name + " " + p.surname + "</td>"+
                    "<td>"+ p.phone + "</td>"+
                    "<td>"+ p.contract_number + "</td>"+
                    "<td>"+ p.m_lat + "</td>"+
                    "<td>"+ p.m_lng + "</td>"+
                "</tr>";
    return linha;
}

$("#finishProcess").on('hidden.bs.modal', function () {
    $("#customersTable>thead tr").remove();
    $("#customersTable>tbody tr").remove();
    $("#tex span").remove();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Documents\feas_v2\resources\views/default/service_boxes/index.blade.php ENDPATH**/ ?>