

<?php $__env->startSection('extra-header'); ?>
<script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/select2-bootstrap4.css')); ?>" rel="stylesheet">
<script type="text/javascript" src="<?php echo e(asset('vendor/js/jquery.mask.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <a class="btn button-without-style btn-sm" href="<?php echo e(route('default.process_stage_three.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Voltar a página de processos">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                            <span class="align-middle">&nbsp;&nbsp;Editar processo existente</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">

                <div class="card-body">
                    <form id="thisForm" action="<?php echo e(route('default.process_stage_three.update', $response)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="inputname">Cliente</label>
                                <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($response->customer()->get()->first()->name); ?> <?php echo e($response->customer()->get()->first()->surname); ?>" readonly>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="inputname">Número do endereço</label>
                                <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($response->address()->get()->first()->number); ?>" readonly>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="city">Cidade</label>
                                <select name="city" id="city" class="form-control selectTwo" style="width: 100%" disabled>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->id); ?>" <?php if($response->address()->get()->first()->cities_id == $city->id): ?> selected <?php endif; ?>><?php echo e(__($city->name)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputname">Descrição do endereço</label>
                                <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($response->address()->get()->first()->end_description); ?>" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputname">Complemento do endereço</label>
                                <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($response->address()->get()->first()->complement); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="responsible_id">Enviar o processo para o usuário:</label>
                                <select name="responsible_id" class="mselectRules form-control">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <span class="float-right">
                            <a class="btn btn-detail" href="<?php echo e(route('default.process_stage_three.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Cancelar e voltar"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                            <button type="submit" class="btn btn-detail">Enviar processo</button>
                        </span>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<script type='text/javascript'>
    $(".mselectRules").select2({
        theme: "bootstrap4"
    });
</script>

<script type="text/javascript">
// VALIDAÇÕES E MÁSCARAS
$("#phone").mask('(00) 00000-0000');

$("#thisForm").submit(function() {
  $("#phone").unmask();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Documents\feas_v2\resources\views/default/process_stage_three/edit.blade.php ENDPATH**/ ?>