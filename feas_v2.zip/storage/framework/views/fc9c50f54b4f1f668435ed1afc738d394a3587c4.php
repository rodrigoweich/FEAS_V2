

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <?php echo e(__('Create a new')); ?>

                </div>
            </div>
        </div>

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.states.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-8">
                                <label for="name"><?php echo e(__('Name')); ?></label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" autofocus>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="uf"><?php echo e(__('UF')); ?></label>
                                <input type="text" class="form-control" id="uf" name="uf" value="<?php echo e(old('uf')); ?>" autofocus>
                            </div>
                        </div>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <span class="float-right">
                            <a class="btn btn-detail" href="<?php echo e(route('admin.states.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Cancel and return')); ?>"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                            <button type="submit" class="btn btn-detail"><?php echo e(__('Create')); ?></button>
                        </span>
                    </form>

                </div>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/admin/states/create.blade.php ENDPATH**/ ?>