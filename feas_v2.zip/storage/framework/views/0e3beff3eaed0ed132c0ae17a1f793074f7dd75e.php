<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="row row-cols-2 row-cols-md-5 col-md-10 text-center">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-users')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-users fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Users')); ?> <span class="badge badge-pill badge-detail"><?php echo e($users); ?></span>
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-tags fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Roles')); ?> <span class="badge badge-pill badge-detail"><?php echo e($roles); ?></span>
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-city fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Cities')); ?>

                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-flag fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('States')); ?>

                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-bullhorn fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Notices')); ?>

                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-chart-pie fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Reports')); ?>

                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-microchip fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Proccess')); ?> - 1
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-microchip fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Proccess')); ?> - 2
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-microchip fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Proccess')); ?> - 3
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-microchip fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Proccess')); ?> - 4
                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-minus fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Cables')); ?>

                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-bookmark fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Boxes')); ?>

                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
            <div class="col mb-4">
                <div class="card rounded-05 main-menu-card">
                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-list fa-lg"></i></h5>
                            <p class="card-text">
                            <?php echo e(__('Process List')); ?>

                            </p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/home.blade.php ENDPATH**/ ?>