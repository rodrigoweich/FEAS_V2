

<?php $__env->startSection('extra-header'); ?>
<script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/select2-bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('fcontent'); ?>
<?php if(!config('global.google_maps_key')): ?>
<div class="container my-5 alert alert-danger">
    <h6 class="m-0 text-justify"><i class="fas fa-exclamation-triangle"></i> Foram encontradas inconsistências na sua chave de acesso do Google Maps API. Por favor, verifique a sua chave e tente novamente.</h6>
</div>
<?php else: ?>
<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
        <div class="list-group list-group-flush">
            <div id="divider">
                <a id="navbarDropdown" class="nav-link dropdown-toggle list-group-item list-group-item-action bg-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <span class="float-right"><i class="fas fa-map"></i></span> <span id="mapTypesDpMenu">Default + Satellite</span> <span class="caret"></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'roadmap', 'Default')">
                        <?php echo e(__('Default')); ?>

                    </a>
                    <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'satellite', 'Satellite')">
                        <?php echo e(__('Satélite')); ?>

                    </a>
                    <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'terrain', 'Default + Terrain')">
                        <?php echo e(__('Default + Terrain')); ?>

                    </a>
                    <a class="dropdown-item" onclick="changeMapType('mapTypesDpMenu', 'hybrid', 'Default + Satellite')">
                        <?php echo e(__('Default + Satellite')); ?>

                    </a>
                </div>
            </div>
            <a onclick="showAlertSave()" class="list-group-item list-group-item-action bg-light"><?php echo e(__('Save modifications')); ?><span class="float-right"><i class="fas fa-map-marked"></i></span></a>
            <a href="<?php echo e(route('default.boxes.index')); ?>" class="list-group-item list-group-item-action bg-light text-danger"><?php echo e(__('Cancel and return')); ?><span class="float-right"><i class="far fa-hand-point-left"></i></span></a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">
        <div class="container-fluid" id="gmap">
        </div>
    </div>
    <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->
<?php endif; ?>

<div class="modal fade" tabindex="-1" role="dialog" id="alertSave">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e(__('Service box information')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form action="<?php echo e(route('default.boxes.update', $data)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <div class="row mb-3">
                        <div class="col">
                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label for="inputname"><?php echo e(__('Name')); ?></label>
                                    <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($data->name); ?>" autofocus>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="city"><?php echo e(__('City')); ?></label>
                                    <select name="city" class="form-control selectTwo" style="width: 100%">
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city->id); ?>" <?php if($city->id == $data->cities_id): ?> selected <?php endif; ?>><?php echo e(__($city->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="lat">Latitude</label>
                                    <input type="text" class="form-control" id="lat" name="lat" value="<?php echo e($data->m_lat); ?>" readonly>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="lng">Longitude</label>
                                    <input type="text" class="form-control" id="lng" name="lng" value="<?php echo e($data->m_lng); ?>" readonly>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="description"><?php echo e(__('Description')); ?></label>
                                    <input type="text" class="form-control" id="description" name="description" value="<?php echo e($data->description); ?>" autofocus>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="amount"><?php echo e(__('Amount')); ?></label>
                                    <input type="number" class="form-control" id="amount" name="amount" max="128" min="0" value="<?php echo e($data->amount); ?>">
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="busy"><?php echo e(__('Busy')); ?></label>
                                    <input type="number" class="form-control" id="busy" name="busy" min="0" value="<?php echo e($data->busy); ?>">
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="available"><?php echo e(__('Available')); ?></label>
                                    <input type="number" class="form-control" id="available" name="available" value="<?php echo e($data->amount - $data->busy); ?>" readonly>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <span class="float-right">
                        <a class="btn btn-danger" href="<?php echo e(route('default.boxes.index')); ?>" role="button"><?php echo e(__('Cancel and return')); ?></a>
                        <button type="submit" class="btn btn-success"><?php echo e(__('Save')); ?></button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal"><?php echo e(__('Close this window')); ?></button>
                    </span>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="alertDeleteElement">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e(__('Service box information')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-justify">
                Você só pode inserir uma posição/construção por viabilidade!
                Para alterar a posição/construção você precisa deletar a posição/construção inserida anteriormente.
                Você realmente deseja prosseguir?
                </p>
                <span class="float-right">
                    <button class="btn btn-danger" onclick="clearMarkers();" data-dismiss="modal"><?php echo e(__('Yes, delete')); ?></button>
                    <button type="button" class="btn btn-primary" data-dismiss="modal"><?php echo e(__('Cancel and close this window')); ?></button>
                </span>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<?php if(config('global.google_maps_key')): ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('global.google_maps_key')); ?>&callback=initMap" async defer></script>
<?php endif; ?>

<script type='text/javascript'>
    $(".selectTwo").select2({
        theme: "bootstrap4"
    });

var gmap;
var insertedBuildings = false;
var marker;
var infoWindowMyPos;

function initMap() {
    gmap = new google.maps.Map(document.getElementById('gmap'), {
        center: {lat: -25.721822, lng: -53.765546},
        mapTypeId: "hybrid",
        zoom: 15,
        zoomControl: true,
        scaleControl: false,
        streetViewControl: false,
        rotateControl: false,
        fullscreenControl: false,
        mapTypeControl: false,
        mapTypeControlOptions: {
            style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
            mapTypeIds: [
                'roadmap',
                'terrain',
                'satellite',
                'hybrid'
            ]
        }
    });

    gmap.setCenter({lat: <?php echo e($data->m_lat); ?>, lng: <?php echo e($data->m_lng); ?>});
    gmap.setZoom(14);
    createNewBoxPoint({lat: <?php echo e($data->m_lat); ?>, lng: <?php echo e($data->m_lng); ?>});

    appendListenerOnMap();
};

function appendListenerOnMap() {
    gmap.addListener('click', function(event) {
        createNewBoxPoint(event.latLng);
    });
};

function createNewBoxPoint(position) {
    if (insertedBuildings == false) {
        marker = new google.maps.Marker({
            position: position,
            map: gmap,
            animation: google.maps.Animation.DROP,
            label: '<?php echo e($data->id); ?>',
            icon: {
                path: "M0 512V48C0 21.49 21.49 0 48 0h288c26.51 0 48 21.49 48 48v464L192 400 0 512z",
                fillColor: "#fff",
                fillOpacity: 1,
                strokeWeight: 0,
                scale: 0.06,
                anchor: new google.maps.Point(200,510),
                labelOrigin: new google.maps.Point(205,190)
            }
        });
        insertedBuildings = true;
        $('#clearMarker').removeAttr('disabled');
        $('#saveMarker').removeAttr('disabled');
        $('#lat').val(marker.getPosition().lat());
        $('#lng').val(marker.getPosition().lng());
        if (infoWindowMyPos == true) {
            infoWindowMyPos.close(gmap);
        }
    } else {
        $('#alertDeleteElement').modal('show');
    }
}

function clearMarkers() {
    marker.setMap(null);
    marker = null;
    insertedBuildings = false;
    $('#clearMarker').attr("disabled", true);
    $('#saveMarker').attr("disabled", true);
};

function showAlertSave() {
    $('#alertSave').modal('show')
};

function changeMapType(target, mapType, htmlText) {
    gmap.setMapTypeId(mapType);
    $("#"+target).html(htmlText);
};
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/default/service_boxes/edit.blade.php ENDPATH**/ ?>