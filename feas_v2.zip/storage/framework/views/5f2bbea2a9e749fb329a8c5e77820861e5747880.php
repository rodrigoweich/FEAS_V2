<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(config('global.type_asset')('/img/system/favicon.ico')); ?>" type="image/x-icon"/>

    <!-- Scripts -->
    <script src="<?php echo e(config('global.type_asset')('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(config('global.type_asset')('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(config('global.type_asset')('js/fontawesome.js')); ?>"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(config('global.type_asset')('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(config('global.type_asset')('css/fontawesome.css')); ?>" rel="stylesheet">
    <?php if (! empty(trim($__env->yieldContent('extra-header')))): ?>
        <?php echo $__env->yieldContent('extra-header'); ?>
    <?php endif; ?>
</head>
<body class="bg-background">
    <div id="app">
        <?php if (! empty(trim($__env->yieldContent('navbar')))): ?>
            <?php echo $__env->yieldContent('navbar'); ?>
        <?php endif; ?>
        <main>
            <?php if (! empty(trim($__env->yieldContent('fcontent')))): ?>
                <?php echo $__env->yieldContent('fcontent'); ?>
            <?php endif; ?>
            <?php if (! empty(trim($__env->yieldContent('content')))): ?>
            <div class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <?php endif; ?>
        </main>
    </div>
    <?php if (! empty(trim($__env->yieldContent('extra-scripts')))): ?>
    <?php echo $__env->yieldContent('extra-scripts'); ?>
    <?php endif; ?>
</body>
</html>
<?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/layouts/app.blade.php ENDPATH**/ ?>