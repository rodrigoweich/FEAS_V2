

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <a class="btn button-without-style btn-sm" href="<?php echo e(route('home')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Return to app')); ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                            <span class="align-middle">&nbsp;&nbsp;<?php echo e(__('Notices')); ?></span>
                        </div>
                        <div class="col-8 text-right">
                            <form action="<?php echo e(route('admin.notices.search')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="input-group input-group-sm">
                                    <input type="text" name="dataToSearch" class="form-control panel-border" placeholder="<?php echo e(__('Filter')); ?>">
                                    <div class="input-group-append">
                                        <button class="btn panel-border" type="submit" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Search')); ?>"><i class="fas fa-search"></i></button>
                                        <a class="btn panel-border" href="<?php echo e(route('admin.notices.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Clear and return')); ?>"><i class="fas fa-undo-alt"></i></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="row">
                        <div class="col text-right">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-notices')): ?>
                            <a class="btn btn-detail btn-sm" href="<?php echo e(route('admin.notices.create')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Create a new')); ?>">
                                <i class="fas fa-plus"></i>
                            </a>
                        <?php endif; ?>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered table-hover table-borderless text-center" style="height: 100px;">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Título</th>
                                    <th>Destaque</th>
                                    <th>Status</th>
                                    <th>Criador</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row" class="align-middle"><?php echo e($data->id); ?></td>
                                    <td class="align-middle"><?php echo e($data->title); ?></td>
                                    <td class="align-middle">
                                        <?php if($data->featured === 1): ?>
                                        <i class="fas text-success fa-check"></i>
                                        <?php else: ?>
                                        <i class="fas text-danger fa-times"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td class="align-middle">
                                        <?php if($data->active === 1): ?>
                                        <i class="fas text-success fa-check"></i>
                                        <?php else: ?>
                                        <i class="fas text-danger fa-times"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td class="align-middle"><?php echo e($data->user->name); ?></td>
                                    <td class="align-middle">
                                        <div class="d-flex align-content-center">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-notices')): ?>
                                            <a href="<?php echo e(route('admin.notices.edit', $data->id)); ?>"><button type="button" class="button-without-style mr-1"><i class="fas text-dark fa-edit"></i></button></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-notices')): ?>
                                        <form action="<?php echo e(route('admin.notices.destroy', $data->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="submit" class="button-without-style ml-1"><i class="fas text-dark fa-trash"></i></button>
                                        </form>
                                        <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12 mt-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-center">
                                <?php echo e($response->onEachSide(1)->links()); ?>

                    </div>
                    <div class="d-flex justify-content-center">
                        <span class="align-middle"><?php echo e(__('Showing')); ?> <?php echo e($response->count()); ?> <?php echo e(__('of')); ?> <?php echo e($response->total()); ?> <?php echo e(__('results')); ?></span>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/admin/notices/index.blade.php ENDPATH**/ ?>