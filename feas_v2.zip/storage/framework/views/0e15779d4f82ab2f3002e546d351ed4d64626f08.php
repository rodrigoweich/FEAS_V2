<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FEAS - Relatório de clientes por caixas</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <style>
        body {
            font-family: Verdana, Arial, Helvetica, sans-serif !important;
            font-size: 12px;
        }

        th, td {
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>

<body>

    <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
            <td width="20%" style="text-align: left !important">
                <img src="<?php echo e(public_path('img/system/feas-logo.png')); ?>" style="width: 100px">
            </td>
            <td width="50%" style="font-size: 16px !important; text-align: center !important;">
                <h3>Relatório de clientes por caixas</h3>
            </td>
            <td width="30%" style="text-align: right !important">
                <b>Rline Telecom LTDA</b><br>
                Rua Cinco - Área Industrial<br>
                CNPJ: 13.500.755/0001-05<br>
                46 3555-8000 / Matriz<br>
                suporte@rline.com.br<br>
            </td>
        </tr>
    </table>

    <div id="middle" style="text-align: center !important">
    <hr>
        <span style="font-size: 12px">
            <a value="<?php echo e(date_default_timezone_set('America/Sao_Paulo')); ?>"></a>
            Este relatório foi gerado dia <?php echo e(date('d/m/Y')); ?> às <?php echo e(date('H:i:s')); ?> por <?php echo e(Auth::user()->name); ?>

        </span>
    <hr>
    </div>

    <div class="container" style="text-align: left !important;">
        <span style="font-size: 12px;">
            <br>Informações sobre a caixa<br><br>Caixa: <?php echo e($box->name); ?><br>
            Cidade: <?php echo e($city->find($box->cities_id)->name); ?><br>
            Quantidade: <?php echo e($box->amount); ?><br>
            Ocupadas: <?php echo e($box->busy); ?><br>
            Livres: <?php echo e($box->amount - $box->busy); ?><br>
            Latitude: <?php echo e($box->m_lat); ?><br>
            Longitude: <?php echo e($box->m_lng); ?><br>
            Descrição: <?php echo e($box->description); ?><br><br>
        </span>
        <?php if($response->count() !== 0): ?>
        <table width="100%">
            <thead>
                <tr style="background-color: #F1F1F1 !important">
                    <th><b>#</b></th>
                    <th>Cliente</th>
                    <th>Telefone</th>
                    <th>Contrato N°</th>
                    <th>End.</th>
                    <th>N° end.</th>
                    <th>Complemento end.</th>
                    <th>Cidade</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($process->id); ?></td>
                    <td><?php echo e($process->name); ?> <?php echo e($process->surname); ?></td>
                    <td><?php echo e($process->phone); ?></td>
                    <td><?php echo e($process->contract_number); ?></td>
                    <td><?php echo e($process->end_description); ?></td>
                    <td><?php echo e($process->number); ?></td>
                    <td><?php echo e($process->complement); ?></td>
                    <td><?php echo e($city->find($process->cities_id)->name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <hr>
        <span style="margin-top: 50% !important">Desculpe, essa consulta não encontrou resultados.</span>
        <?php endif; ?>
    </div>

</body><?php /**PATH D:\Data\Documents\feas_v2\resources\views/relatorios_pdfs/customersbybox.blade.php ENDPATH**/ ?>