

<?php $__env->startSection('extra-header'); ?>
<script src="<?php echo e(config('global.type_asset')('js/select2.js')); ?>"></script>
<link href="<?php echo e(config('global.type_asset')('css/select2.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center mb-4">
        <?php if(Storage::disk('public')->exists($user->avatar)): ?>
        <span><img id="prevImg" src="<?php echo e(config('global.type_asset')('/storage/'.Auth::user()->avatar)); ?>" alt="Avatar" class="avatar-image shadow-lg" style="width: 130px; height: 130px"></span>
        <?php else: ?>
        <span><img id="prevImg" src="<?php echo e(config('global.type_asset')('img/users/avatar.png')); ?>" alt="Avatar" class="avatar-image shadow-lg" style="width: 130px; height: 130px"></span>
        <?php endif; ?>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow">
                <div class="card-header text-center"><?php echo e($user->name); ?><?php echo e(__('\'s profile')); ?></div>

                <div class="card-body">

                    <form action="<?php echo e(route('users.profile.update', $user)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>


                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputname"><?php echo e(__('Name')); ?></label>
                                <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($user->name); ?>" autofocus>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputemail"><?php echo e(__('E-Mail')); ?></label>
                                <input type="email" class="form-control" id="inputemail" name="email" value="<?php echo e($user->email); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="inputpassword"><?php echo e(__('Current password')); ?></label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="currentPw" id="currentPw" autofocus>
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Show password')); ?>" onclick="showPassword('currentPw')"><i class="fas fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="inputpassword"><?php echo e(__('New password')); ?></label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="newPw" id="newPw" autofocus>
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Generate password')); ?>" onclick="gerarPassword()"><i class="fas fa-key"></i></button>
                                    </div>
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Show password')); ?>" onclick="showPassword('newPw')"><i class="fas fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="inputpassword"><?php echo e(__('Confirm new password')); ?></label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="confirmNewPw" id="confirmNewPw" autofocus>
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Show password')); ?>" onclick="showPassword('confirmNewPw')"><i class="fas fa-eye"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="imgInp" name="avatar_image" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
                                    <label class="custom-file-label" for="imgInp" id="imgLInp"><?php echo e(__('Choose profile picture')); ?></label>
                                </div>
                            </div>
                        </div>
                        <?php if($user->roles()->count() >= 1): ?>
                        <div class="form-row">
                            <div class="form-group col-md-12 text-justify">
                                <span><?php echo e(__('Your permissions')); ?>:</span><br/>
                                <?php $__currentLoopData = $user->roles()->get()->pluck('name')->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    #<?php echo e(__($value)); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            Ops!!! parece que algo deu errado. Por favor, verifique se:
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <span class="float-right">
                            <a class="btn btn-danger" href="<?php echo e(route('home')); ?>" role="button" data-toggle="tooltip"
                            data-placement="top" title="<?php echo e(__('Cancel and return')); ?>"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Update profile')); ?></button>
                        </span>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<script type='text/javascript'>
    function showPassword(inputId) {
        if($('#'+inputId).is("input:text")) {
            $('#'+inputId).attr('type', 'password');
        } else if($('#'+inputId).is('input:password')) {
            $('#'+inputId).attr('type', 'text');
        };
    };

    function mostrarPassword() {
        if($("#inputPasswd").is("input:text")) {
            $("#inputPasswd").attr("type", "password");
        } else if($("#inputPasswd").is("input:password")) {
            $("#inputPasswd").attr("type", "text");
        }
    };
    function gerarPassword() {
        return document.getElementById("inputPasswd").value = Math.random().toString(36).slice(-10);
    };
</script>

<script type='text/javascript'>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        
        reader.onload = function(e) {
        $('img#prevImg').attr('src', e.target.result);
        }
        
        reader.readAsDataURL(input.files[0]); // convert to base64 string
    }
}
$("#imgInp").change(function() {
    readURL(this);
    var file = $(this)[0].files[0]
    if (file){
        $('#imgLInp').html(file.name);
    }
});

$("#buttonPassword").click(function(){
    $('#showPasswordModal').modal('show');
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/users/profile.blade.php ENDPATH**/ ?>