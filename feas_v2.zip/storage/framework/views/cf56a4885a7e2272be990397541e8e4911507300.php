

<?php $__env->startSection('extra-header'); ?>
<link href="<?php echo e(asset('vendor/farbtastic/farbtastic.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <?php echo e(__('Edit existing')); ?>

                </div>
            </div>
        </div>

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <form action="<?php echo e(route('default.cables.update', $cable)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <div class="row mb-3">
                            <div class="col">
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="inputname">Nome</label>
                                        <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($cable->name); ?>" autofocus>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-8">
                                        <label for="lat">Cor do cabo</label>
                                        <input class="form-control" type="text" id="color" name="color" value="<?php echo e($cable->color); ?>" />
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="inputsize">Tamanho</label>
                                        <input type="number" min="2" max="6" class="form-control" id="inputsize" name="size" value="<?php echo e($cable->size); ?>" autofocus>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="inputshortcut" name="inputshortcut" <?php if($cable->dotted == 1): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label" id="labelforshortcut" for="inputshortcut">Pontilhado: Sim/Não</label>
                                        </div>
                                    </div>
                                </div>
                                <div id="dotted_repeat" <?php if($cable->dotted == 0 ): ?>class="not-display" <?php endif; ?>>
                                    <div class="form-row">
                                        <hr class="solid">
                                        <div class="form-group col-md-12">
                                            <label for="inputrepeat">Espaçamento</label>
                                            <input type="number" min="12" max="35" class="form-control" id="inputrepeat" name="repeat" value="<?php echo e($cable->dotted_repeat); ?>" autofocus>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center">
                                <div class="d-flex justify-content-center align-items-center">
                                    <div id="colorpicker"></div>
                                </div>
                            </div>
                            <div class="col">
                                <?php if(!config('global.google_maps_key')): ?>
                                <div class="container my-5 alert alert-danger">
                                    <h6 class="m-0 text-justify"><i class="fas fa-exclamation-triangle"></i> Foram encontradas inconsistências na sua chave de acesso do Google Maps API. Por favor, verifique a sua chave e tente novamente.</h6>
                                </div>
                                <?php else: ?>
                                <div id="gmap" class="shadow-lg rounded" style="height: 30vh;"></div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <span class="float-right">
                            <a class="btn btn-detail" href="<?php echo e(route('default.cables.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Cancel and return')); ?>"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                            <button type="submit" class="btn btn-detail"><?php echo e(__('Edit')); ?></button>
                        </span>
                    </form>

                </div>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<script src="<?php echo e(asset('vendor/farbtastic/farbtastic.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#colorpicker').farbtastic('#color');
    });
</script>
<script type='text/javascript'>
    $('#inputshortcut').ready(function () {
        return checkStatus();
    });
    $('#inputshortcut').click(function () {
        return checkStatus();
    });

    function checkStatus() {
        if ($('#inputshortcut').is(":checked")) {
            $('#labelforshortcut').html('Pontilhado: sim');
        } else {
            $('#labelforshortcut').html('Pontilhado: não');
        }
    }
</script>
<script type='text/javascript'>
    $('#inputshortcut').click(function () {
        if ($(this).is(':checked')) {
            $("#dotted_repeat").removeClass('not-display');
        } else {
            $("#dotted_repeat").addClass('not-display');
        }
    });
</script>

<?php if(config('global.google_maps_key')): ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('global.google_maps_key')); ?>&callback=initMap" async defer></script>
<?php endif; ?>

<script>
    var gmap;
    var lineSize = 4;
    var lineColor = '#FF0000';
    var lineDotted = false;
    var lineRepeat = 20;
    var line;
    
    function initMap() {
        gmap = new google.maps.Map(document.getElementById('gmap'), {
            center: {lat: -25.714640, lng: -53.770253},
            mapTypeId: "satellite",
            zoom: 17,
            zoomControl: false,
            scaleControl: false,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: false,
            mapTypeControl: false,
            mapTypeControlOptions: {
                style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
                mapTypeIds: [
                    'roadmap',
                    'terrain',
                    'satellite',
                    'hybrid'
                ]
            },
            gestureHandling: 'none'
        });
        createLine(lineSize, lineColor, lineDotted, lineRepeat, lineRepeat);
    };

    function createLine(size, color, dotted, repeat) {
        
        var lineCoordinates = [
          {lat: -25.714019, lng: -53.770141},
          {lat: -25.714594, lng: -53.770807},
          {lat: -25.715437, lng: -53.769833}
        ];
        
        if (dotted == true) {
            var lineSymbol = {
                path: 'M 0,-1 0,1',
                strokeOpacity: 1,
                scale: size
            };

            line = new google.maps.Polyline({
                path: lineCoordinates,
                strokeColor: color,
                strokeOpacity: 0,
                icons: [{
                    icon: lineSymbol,
                    offset: '0',
                    repeat: repeat + 'px'
                }]
            });
        } else {
            line = new google.maps.Polyline({
                path: lineCoordinates,
                geodesic: true,
                strokeColor: color,
                strokeOpacity: 1.0,
                strokeWeight: size
            });
        }
        addLine();
    }

    $('#inputsize').click(function () {
        lineSize = $('#inputsize').val();
        removeLine();
        createLine(lineSize, lineColor, lineDotted, lineRepeat, lineRepeat);
    })

    $('#inputrepeat').click(function () {
        lineRepeat = $('#inputrepeat').val();
        removeLine();
        createLine(lineSize, lineColor, lineDotted, lineRepeat, lineRepeat);
    })

    $('#colorpicker').mousemove(function () {
        lineColor = $("#color").val();
        removeLine();
        createLine(lineSize, lineColor, lineDotted, lineRepeat);
    })

    $('#labelforshortcut').click(function () {
        if(lineDotted == false) {
            lineDotted = true;
            removeLine();
            createLine(lineSize, lineColor, lineDotted, lineRepeat);
        } else if(lineDotted == true) {
            lineDotted = false;
            removeLine();
            createLine(lineSize, lineColor, lineDotted, lineRepeat);
        }
    })

    function addLine() {
        line.setMap(gmap);
    }
    function removeLine() {
        line.setMap(null);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/default/cables/edit.blade.php ENDPATH**/ ?>