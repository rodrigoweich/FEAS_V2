<div class="modal <?php echo e($animation ?? 'fade'); ?> <?php echo e($class ?? ''); ?>" id="<?php echo e($id ?? 'modal'); ?>">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <?php if(isset($title)): ?>
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e($title); ?></h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <div class="modal-body">
                <?php echo e($slot); ?>

            </div>

            <?php if(isset($footer)): ?>
                <div class="modal-footer">
                    <?php echo e($footer); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH D:\18072020\Documents\Projects\feas_v2\resources\views/components/modal.blade.php ENDPATH**/ ?>