<table cellpadding="0" cellspacing="0" border="0" width="100%">
    <tr>
        <td width="36%">
            <img src="<?php echo e(asset('img/system/feas-logo.png')); ?>" width="300px" border="0"> 
        </td>
        <td width="40%">
            <b>Empresa: d</b>
            <br><b>CNPJ: f</b>
            <br><b>Usuário: a</b>
            <br>
        </td>
        <td width="20%">
            <b>Tel.: d</b>
            <br><b>Cel.: f}</b>
        </td>
        <td></td>
        <td width="8">
            <a value="<?php echo e(date_default_timezone_set('America/Sao_Paulo')); ?>"></a>
            <b>Data</b>  <?php echo e(date('m/d/Y H:i:s')); ?>

        </td>
    </tr>
</table>


<hr> 
<table cellpadding="0" cellspacing="0" border="0" width="100%">
    <tr>
        <td width="75%">
            <b>Cliente:</b> A
            <br><b>Projeto:</b> s
            <br><b>Fase:</b> D
        </td>
        <td width="25%">
            <b>Telefone:</b> a
            <br><b>Celular:</b> f
            <br><b>Área de Construção: </b> s
        </td>
    </tr>
</table>


<table width="100%" >
<?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($data->name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH D:\Data\Documents\feas_v2\resources\views//pdf/relatorios.blade.php ENDPATH**/ ?>