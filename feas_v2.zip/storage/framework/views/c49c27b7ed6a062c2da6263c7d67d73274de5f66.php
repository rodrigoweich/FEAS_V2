

<?php $__env->startSection('extra-header'); ?>
<script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <a class="btn button-without-style btn-sm" href="<?php echo e(route('admin.roles.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Voltar a página de funções">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                            <span class="align-middle">&nbsp;&nbsp;Editar uma função existente</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.roles.update', $role)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="inputname">Nome</label>
                                <input type="text" class="form-control" id="inputname" name="name" value="<?php echo e($role->name); ?>" required autofocus>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="rules[]">Autorizações:</label>
                                <select name="rules[]" class="mselectRules form-control" multiple="true">
                                    <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rule->id); ?>" <?php if($role->rules->pluck('id')->contains($rule->id)): ?> selected <?php endif; ?>><?php echo e(__($rule->display_name)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <span class="float-right">
                            <a class="btn btn-detail" href="<?php echo e(route('admin.roles.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Cancelar e voltar"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                            <button type="submit" class="btn btn-detail">Aplicar mudanças</button>
                        </span>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<script type='text/javascript'>
    $(".mselectRules").select2();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Documents\feas_v2\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>