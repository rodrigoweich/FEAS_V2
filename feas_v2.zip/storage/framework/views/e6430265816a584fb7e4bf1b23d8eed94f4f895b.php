

<?php $__env->startSection('extra-header'); ?>
<script src="<?php echo e(asset('vendor/bootstrap-notify-3.1.3/bootstrap-notify.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-12 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <a class="btn button-without-style btn-sm" href="<?php echo e(route('home')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Retornar ao app">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                            <span class="align-middle">&nbsp;&nbsp;Processo estágio - 4</span>
                        </div>
                        <div class="col-8 text-right">
                            <form action="<?php echo e(route('default.process_stage_four.search')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="input-group input-group-sm">
                                    <input type="text" name="dataToSearch" class="form-control panel-border" placeholder="Pesquise por cliente, usuário, técnico, cidade ou data (AAAA-MM-DD)">
                                    <div class="input-group-append">
                                        <button class="btn panel-border" type="submit" data-toggle="tooltip" data-placement="top" title="Pesquisar"><i class="fas fa-search"></i></button>
                                        <a class="btn panel-border" href="<?php echo e(route('default.process_stage_four.index')); ?>" role="button" data-toggle="tooltip" data-placement="top" title="Cancelar e voltar"><i class="fas fa-undo-alt"></i></a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered table-hover table-borderless text-center" style="height: 100px;">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Cliente</th>
                                    <th>Ícone</th>
                                    <th>Cidade</th>
                                    <th>Técnico resp.</th>
                                    <th>Iniciado por</th>
                                    <th>Iniciado em</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr <?php if($data->responsible_id === Auth::user()->id): ?> class="table-detail" <?php endif; ?>>
                                    <td scope="row" class="align-middle"><?php echo e($data->id); ?></td>
                                    <td class="align-middle"><?php echo e($customer->find($data->customers_id)->name); ?> <?php echo e($customer->find($data->customers_id)->surname); ?></td>
                                    <td class="align-middle"><i class="<?php echo e($customer->find($data->customers_id)->m_icon); ?> fa-lg"></i></td>
                                    <td class="align-middle"><?php echo e($city->find($address->find($data->customers_id)->cities_id)->name); ?></td>
                                    <td class="align-middle"><?php echo e($user->find($data->responsible_id)->name); ?></td>
                                    <td class="align-middle"><?php echo e($user->find($data->users_id)->name); ?></td>
                                    <td class="align-middle"><?php echo e($data->created_at); ?></td>
                                    <td class="align-middle">
                                        <div class="d-flex align-content-center">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-process-stage-four')): ?>
                                                <?php if($data->responsible_id === Auth::user()->id): ?>
                                                    <a id="edit-button" href="<?php echo e(route('default.process_stage_four.edit', $data->id)); ?>"><button type="button" class="button-without-style mr-1" data-toggle="tooltip" data-placement="top" title="Editar"><i class="fas text-dark fa-edit fa-lg"></i></button></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('previous-process-stage-four')): ?>
                                                <a href="<?php echo e(route('default.process.previous_stage', $data->id)); ?>"><button type="button" class="button-without-style mr-1" data-toggle="tooltip" data-placement="top" title="Voltar"><i class="fas text-danger fa-arrow-left fa-lg"></i></button></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('next-process-stage-four')): ?>
                                                <?php if($data->route !== null): ?>
                                                <a href="<?php echo e(route('default.process.next_stage', $data->id)); ?>"><button type="button" class="button-without-style mr-1" data-toggle="tooltip" data-placement="top" title="Avançar"><i class="fas text-success fa-arrow-right fa-lg"></i></button></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12 mt-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-center">
                        <?php echo e($response->onEachSide(1)->links()); ?>

                    </div>
                    <div class="d-flex justify-content-center">
                        <span class="align-middle">Mostrando <?php echo e($response->count()); ?> de <?php echo e($response->total()); ?> resultados</span>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
<script type='text/javascript'>
$("#edit-button").click(function(event) {
    <?php if($hasCables === false): ?>
        event.stopPropagation();
        event.preventDefault();
        $.notify({
            message: "Você só pode iniciar um processo se houver ao menos um cabo cadastrado no sistema. <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-cables')): ?><a href='<?php echo e(route('default.cables.create')); ?>'>Clique aqui</a> para cadastrar um. <?php else: ?> Por favor, contate o seu administrador. <?php endif; ?>"
        }, {
            type: "danger"
        });
    <?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Documents\feas_v2\resources\views/default/process_stage_four/index.blade.php ENDPATH**/ ?>