<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FEAS - Relatório de processos</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <style>
        body {
            font-family: Verdana, Arial, Helvetica, sans-serif !important;
            font-size: 12px;
        }

        th, td {
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>

<body>

    <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
            <td width="20%" style="text-align: left !important">
                <img src="<?php echo e(public_path('img/system/feas-logo.png')); ?>" style="width: 100px">
            </td>
            <td width="50%" style="font-size: 16px !important; text-align: center !important;">
                <h3>Relatório de processos</h3>
            </td>
            <td width="30%" style="text-align: right !important">
                <b>Rline Telecom LTDA</b><br>
                Rua Cinco - Área Industrial<br>
                CNPJ: 13.500.755/0001-05<br>
                46 3555-8000 / Matriz<br>
                suporte@rline.com.br<br>
            </td>
        </tr>
    </table>

    <div id="middle" style="text-align: center !important">
    <hr>
        <span style="font-size: 12px">
            <a value="<?php echo e(date_default_timezone_set('America/Sao_Paulo')); ?>"></a>
            Este relatório foi gerado dia <?php echo e(date('d/m/Y')); ?> às <?php echo e(date('H:i:s')); ?> por <?php echo e(Auth::user()->name); ?>

        </span>
    <hr>
    </div>

    <div class="container" style="text-align: left !important;">
        <?php if($response->count() !== 0): ?>
        <table width="100%">
            <thead>
                <tr style="background-color: #F1F1F1 !important">
                    <?php if($option_id === 'true'): ?>
                    <th><b>#</b></th>
                    <?php endif; ?>
                    <?php if($option_customer === 'true'): ?>
                    <th>Cliente</th>
                    <?php endif; ?>
                    <?php if($option_icon === 'true'): ?>
                    <th>Representação</th>
                    <?php endif; ?>
                    <?php if($option_city === 'true'): ?>
                    <th>Cidade</th>
                    <?php endif; ?>
                    <?php if($option_started_by === 'true'): ?>
                    <th>Iniciado por</th>
                    <?php endif; ?>
                    <?php if($option_started_in === 'true'): ?>
                    <th>Iniciado em</th>
                    <?php endif; ?>
                    <?php if($option_tech === 'true'): ?>
                    <th>Técnico</th>
                    <?php endif; ?>
                    <?php if($option_stage === 'true'): ?>
                    <th>Etapa</th>
                    <?php endif; ?>
                    <?php if($option_meters_ap === 'true'): ?>
                    <th>Distância aproximada</th>
                    <?php endif; ?>
                    <?php if($option_meters_real === 'true'): ?>
                    <th>Distância real</th>
                    <?php endif; ?>
                    <?php if($options_difference_meters === 'true'): ?>
                    <th>Diferença de distância</th>
                    <?php endif; ?>
                    <?php if($option_cable === 'true'): ?>
                    <th>Cabo utilizado</th>
                    <?php endif; ?>
                    <?php if($option_finished_by === 'true'): ?>
                    <th>Finalizado por</th>
                    <?php endif; ?>
                    <?php if($option_notifications === 'true'): ?>
                    <th>Notificações</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($option_id === 'true'): ?>
                    <td><?php echo e($process->id); ?></td>
                    <?php endif; ?>

                    <?php if($option_customer === 'true'): ?>
                    <td><?php echo e($customer->find($process->customers_id)->name); ?> <?php echo e($customer->find($process->customers_id)->surname); ?></td>
                    <?php endif; ?>

                    <?php if($option_icon === 'true'): ?>
                        <?php if($customer->find($process->customers_id)->m_icon === "fas fa-home"): ?>
                        <td>Casa</td>
                        <?php elseif($customer->find($process->customers_id)->m_icon === "fas fa-hotel"): ?>
                        <td>Hotel</td>
                        <?php elseif($customer->find($process->customers_id)->m_icon === "fas fa-building"): ?>
                        <td>Construção</td>
                        <?php elseif($customer->find($process->customers_id)->m_icon === "fas fa-hospital"): ?>
                        <td>Hospital</td>
                        <?php elseif($customer->find($process->customers_id)->m_icon === "fas fa-store"): ?>
                        <td>Loja</td>
                        <?php elseif($customer->find($process->customers_id)->m_icon === "fas fa-warehouse"): ?>
                        <td>Armazém</td>
                        <?php elseif($customer->find($process->customers_id)->m_icon === "fas fa-church"): ?>
                        <td>Igreja</td>
                        <?php elseif($customer->find($process->customers_id)->m_icon === "fas fa-graduation-cap"): ?>
                        <td>Centro educacional</td>
                        <?php elseif($customer->find($process->customers_id)->m_icon === "fas fa-industry"): ?>
                        <td>Indústria</td>
                        <?php else: ?>
                        <td>Não definido</td>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if($option_city === 'true'): ?>
                    <td><?php echo e($city->find($address->find($process->customers_id)->cities_id)->name); ?></td>
                    <?php endif; ?>

                    <?php if($option_started_by === 'true'): ?>
                    <td><?php echo e($user->find($process->users_id)->name); ?></td>
                    <?php endif; ?>

                    <?php if($option_started_in === 'true'): ?>
                    <td><?php echo e($process->created_at); ?></td>
                    <?php endif; ?>

                    <?php if($option_tech === 'true'): ?>
                        <?php if($process->responsible_id !== null): ?>
                        <td><?php echo e($user->find($process->responsible_id)->name); ?></td>
                        <?php else: ?>
                        <td>Indefinido</td>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($option_stage === 'true'): ?>
                    <?php if($process->stage === 0): ?>
                    <td>Comercial</td>
                    <?php elseif($process->stage === 1): ?>
                    <td>Viabilidade</td>
                    <?php elseif($process->stage === 2): ?>
                    <td>Operacional</td>
                    <?php elseif($process->stage === 3): ?>
                    <td>Técnico</td>
                    <?php elseif($process->stage === 4): ?>
                    <td>SAC</td>
                    <?php elseif($process->stage === 5): ?>
                    <td>Finalizado</td>
                    <?php else: ?>
                    <td>Indefinido</td>
                    <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($option_meters_ap === 'true'): ?>
                        <?php if($process->meters !== null): ?>
                        <td><?php echo e($process->meters); ?> metros</td>
                        <?php else: ?>
                        <td>Indefinido</td>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($option_meters_real === 'true'): ?>
                        <?php if($process->real_meters !== null): ?>
                        <td><?php echo e($process->real_meters); ?> metros</td>
                        <?php else: ?>
                        <td>Indefinido</td>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($options_difference_meters === 'true'): ?>
                        <?php if($process->real_meters !== null && $process->meters !== null): ?>
                            <?php if($process->real_meters - $process->meters < 0): ?>
                            <td><?php echo e(abs($process->real_meters - $process->meters)); ?> metros a menos</td>
                            <?php else: ?>
                            <td><?php echo e($process->real_meters - $process->meters); ?> metros a mais</td>
                            <?php endif; ?>
                        <?php else: ?>
                        <td>Indefinido</td>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($option_cable === 'true'): ?>
                        <?php if($process->cables_id !== null): ?>
                        <td><?php echo e($cables->find($process->cables_id)->name); ?></td>
                        <?php else: ?>
                        <td>Indefinido</td>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($option_finished_by === 'true'): ?>
                        <?php if($process->users_id_finished !== null): ?>
                        <td><?php echo e($user->find($process->users_id_finished)->name); ?></td>
                        <?php else: ?>
                        <td>Indefinido</td>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php if($option_notifications === 'true'): ?>
                        <?php if($process->notified !== null): ?>
                        <td><?php echo e($process->notified); ?></td>
                        <?php else: ?>
                        <td>Indefinido</td>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <span style="margin-top: 50% !important">Desculpe, essa consulta não encontrou resultados.</span>
        <?php endif; ?>
    </div>

</body><?php /**PATH D:\Data\Documents\feas_v2\resources\views/relatorios_pdfs/processes.blade.php ENDPATH**/ ?>