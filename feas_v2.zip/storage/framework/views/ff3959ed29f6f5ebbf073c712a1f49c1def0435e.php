<?php $__env->startSection('extra-header'); ?>
<link href="<?php echo e(config('global.type_asset')('vendor/css/home-timeline.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->startComponent('components.navbar'); ?>
<?php if (isset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36)): ?>
<?php $component = $__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36; ?>
<?php unset($__componentOriginalfbb67f1e1089894701a2681a454eed261a531a36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('home-timeline')): ?>
<div class="container" id="procces_timeline">
    <h1>Linha do tempo de processos</h1>
    <div class="flex-parent">
        <div class="input-flex-container">
            <input type="radio" name="timeline-dot" data-description="1" checked>
            <div class="dot-info" data-description="1">
                <span class="year">1</span>
                <span class="label">Processo estágio - 1</span>
            </div>
            <input type="radio" name="timeline-dot" data-description="2">
            <div class="dot-info" data-description="2">
                <span class="year">2</span>
                <span class="label">Processo estágio - 2</span>
            </div>
            <input type="radio" name="timeline-dot" data-description="3">
            <div class="dot-info" data-description="3">
                <span class="year">3</span>
                <span class="label">Processo estágio - 3</span>
            </div>
            <input type="radio" name="timeline-dot" data-description="4">
            <div class="dot-info" data-description="4">
                <span class="year">4</span>
                <span class="label">Processo estágio - 4</span>
            </div>
            <input type="radio" name="timeline-dot" data-description="5">
            <div class="dot-info" data-description="5">
                <span class="year">5</span>
                <span class="label">Processo estágio - 5</span>
            </div>
            <div id="timeline-descriptions-wrapper">
                <p data-description="1">
                    <span class="row d-flex justify-content-center mb-2 text-center" style="font-size: 16px !important">
                        <?php if($processes_stage_one === 0): ?>
                            Desculpe, este estágio não contém nenhum processo. =/
                        <?php else: ?>
                            O primeiro estágio contém <?php echo e($processes_stage_one); ?> <?php if($processes_stage_one === 1): ?> processo <?php else: ?> processos <?php endif; ?> em andamento<br>
                            Último processo aberto em nome de <?php echo e($customer->find($process->customers_id)->name); ?> <?php echo e($customer->find($process->customers_id)->surname); ?>

                        <?php endif; ?>
                    </span>
                    <?php if($processes_stage_one !== 0): ?>
                    <span class="row d-flex justify-content-center mt-2">
                        <a href="<?php echo e(route('default.process_stage_one.index')); ?>"><button class="btn btn-detail">Visualizar <?php if($processes_stage_one === 1): ?> processo <?php else: ?> processos <?php endif; ?></button></a>
                    </span>
                    <?php endif; ?>
                </p>
                <p data-description="2">
                    <span class="row d-flex justify-content-center mb-2 text-center" style="font-size: 16px !important">
                        <?php if($processes_stage_two === 0): ?>
                            Desculpe, este estágio não contém nenhum processo. =/
                        <?php else: ?>
                            O segundo estágio contém <?php echo e($processes_stage_two); ?> <?php if($processes_stage_two === 1): ?> processo <?php else: ?> processos <?php endif; ?> em andamento<br>
                            Último processo nesse estágio está em nome de <?php echo e($customer->find($process->where('stage', 1)->get()->last()->customers_id)->name); ?> <?php echo e($customer->find($process->where('stage', 1)->get()->last()->customers_id)->surname); ?>

                        <?php endif; ?>
                    </span>
                    <?php if($processes_stage_two !== 0): ?>
                    <span class="row d-flex justify-content-center mt-2">
                        <a href="<?php echo e(route('default.process_stage_two.index')); ?>"><button class="btn btn-detail">Visualizar processos</button></a>
                    </span>
                    <?php endif; ?>
                </p>
                <p data-description="3">
                    <span class="row d-flex justify-content-center mb-2 text-center" style="font-size: 16px !important">
                        <?php if($processes_stage_three === 0): ?>
                            Desculpe, este estágio não contém nenhum processo. =/
                        <?php else: ?>
                            O terceiro estágio contém <?php echo e($processes_stage_three); ?> <?php if($processes_stage_three === 1): ?> processo <?php else: ?> processos <?php endif; ?> em andamento<br>
                            Último processo nesse estágio está em nome de <?php echo e($customer->find($process->where('stage', 2)->get()->last()->customers_id)->name); ?> <?php echo e($customer->find($process->where('stage', 2)->get()->last()->customers_id)->surname); ?>

                        <?php endif; ?>
                    </span>
                    <?php if($processes_stage_three !== 0): ?>
                    <span class="row d-flex justify-content-center mt-2">
                        <a href="<?php echo e(route('default.process_stage_three.index')); ?>"><button class="btn btn-detail">Visualizar processos</button></a>
                    </span>
                    <?php endif; ?>
                </p>
                <p data-description="4">
                    <span class="row d-flex justify-content-center mb-2 text-center" style="font-size: 16px !important">
                        <?php if($processes_stage_four === 0): ?>
                            Desculpe, este estágio não contém nenhum processo. =/
                        <?php else: ?>
                            O quarto estágio contém <?php echo e($processes_stage_four); ?> <?php if($processes_stage_four === 1): ?> processo <?php else: ?> processos <?php endif; ?> em andamento<br>
                            Último processo nesse estágio está em nome de <?php echo e($customer->find($process->where('stage', 3)->get()->last()->customers_id)->name); ?> <?php echo e($customer->find($process->where('stage', 3)->get()->last()->customers_id)->surname); ?>

                        <?php endif; ?>
                    </span>
                    <?php if($processes_stage_four !== 0): ?>
                    <span class="row d-flex justify-content-center mt-2">
                        <a href="<?php echo e(route('default.process_stage_four.index')); ?>"><button class="btn btn-detail">Visualizar processos</button></a>
                    </span>
                    <?php endif; ?>
                </p>
                <p data-description="5">
                    <span class="row d-flex justify-content-center mb-2 text-center" style="font-size: 16px !important">
                        <?php if($processes_stage_five === 0): ?>
                            Desculpe, este estágio não contém nenhum processo. =/
                        <?php else: ?>
                            O quarto estágio contém <?php echo e($processes_stage_five); ?> <?php if($processes_stage_five === 1): ?> processo <?php else: ?> processos <?php endif; ?> em andamento<br>
                            Último processo nesse estágio está em nome de <?php echo e($customer->find($process->where('stage', 4)->get()->last()->customers_id)->name); ?> <?php echo e($customer->find($process->where('stage', 4)->get()->last()->customers_id)->surname); ?>

                        <?php endif; ?>
                    </span>
                    <?php if($processes_stage_five !== 0): ?>
                    <span class="row d-flex justify-content-center mt-2">
                        <a href="<?php echo e(route('default.process_stage_five.index')); ?>"><button class="btn btn-detail">Visualizar processos</button></a>
                    </span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="container" id="shortcut_buttons">
    <div class="row justify-content-center">
            <!-- USUÁRIOS -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-users')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-users fa-lg"></i>
                                <p class="card-text">
                                    Usuários
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /USUÁRIOS -->
            <!-- FUNÇÕES -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-roles')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-tags fa-lg"></i>
                                <p class="card-text">
                                    Funções
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /FUNÇÕES -->
            <!-- CIDADES -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-cities')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('admin.cities.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-city fa-lg"></i>
                                <p class="card-text">
                                    Cidades
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /CIDADES -->
            <!-- ESTADOS -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-states')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('admin.states.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-flag fa-lg"></i>
                                <p class="card-text">
                                    Estados
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /ESTADOS -->
            <!-- NOTICIAS -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-states')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('admin.notices.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-bullhorn fa-lg"></i>
                                <p class="card-text">
                                    Notícias
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /NOTICIAS -->
            <!-- RELATÓRIOS -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('free-access-for-reports')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('reports.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-chart-pie fa-lg"></i>
                                <p class="card-text">
                                Relatórios
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /RELATÓRIOS -->
            <!-- PROCESSO ESTÁGIO 1 -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-process-stage-one')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.process_stage_one.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-microchip fa-lg"></i>
                                <p class="card-text">
                                Processo estágio - 1
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /PROCESSO ESTÁGIO 1 -->
            <!-- PROCESSO ESTÁGIO 2 -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-process-stage-two')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.process_stage_two.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-microchip fa-lg"></i>
                                <p class="card-text">
                                Processo estágio - 2
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /PROCESSO ESTÁGIO 2 -->
            <!-- PROCESSO ESTÁGIO 3 -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-process-stage-three')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.process_stage_three.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-microchip fa-lg"></i>
                                <p class="card-text">
                                Processo estágio - 3
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /PROCESSO ESTÁGIO 3 -->
            <!-- PROCESSO ESTÁGIO 4 -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-process-stage-four')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.process_stage_four.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-microchip fa-lg"></i>
                                <p class="card-text">
                                Processo estágio - 4
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /PROCESSO ESTÁGIO 4 -->
            <!-- PROCESSO ESTÁGIO 5 -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-process-stage-five')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.process_stage_five.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-microchip fa-lg"></i>
                                <p class="card-text">
                                Processo estágio - 5
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /PROCESSO ESTÁGIO 5 -->
            <!-- CABOS -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-cables')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.cables.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-minus fa-lg"></i>
                                <p class="card-text">
                                Cabos
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /CABOS -->
            <!-- CAIXAS -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-service_boxes')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.boxes.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-bookmark fa-lg"></i>
                                <p class="card-text">
                                Caixas
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /CAIXAS -->
            <!-- HISTÓRICO DE PROCESSOS -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-process-history')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.process_history.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-list fa-lg"></i>
                                <p class="card-text">
                                Histórico de processos
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /HISTÓRICO DE PROCESSOS -->
            <!-- LISTA DE PROCESSOS -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-general-process')): ?>
                <div class="col-sm-6 col-md-4 col-lg-2 mb-4 text-center">
                    <div class="card rounded-05 main-menu-card h-100">
                        <a href="<?php echo e(route('default.process_list.index')); ?>" class="btn">
                            <div class="card-body">
                                <i class="fas fa-list fa-lg"></i>
                                <p class="card-text">
                                Lista de processos
                                </p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /LISTA DE PROCESSOS -->
    </div>
</div>

<div class="container" id="notices_panel">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Mural de notícias e atualizações</div>
                <div class="card-body">
                    <?php if($notices->count() === 0): ?>
                        Desculpe, no momento não temos nada para exibir.
                    <?php else: ?>
                        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($notice->featured === 1): ?>
                            <p class="text-justify text-detail"><i class="fas text-warning fa-star" data-toggle="tooltip" data-placement="top" title="Esta notícia é importante"></i> <span class="font-weight-bold"><?php echo e($notice->title); ?></span> -> <?php echo e($notice->description); ?></p>
                            <?php else: ?>
                            <p class="text-justify"><span class="font-weight-bold"><?php echo e($notice->title); ?></span> -> <?php echo e($notice->description); ?></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Documents\feas_v2\resources\views/home.blade.php ENDPATH**/ ?>